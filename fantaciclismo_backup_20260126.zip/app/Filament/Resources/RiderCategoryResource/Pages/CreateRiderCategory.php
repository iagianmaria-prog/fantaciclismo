<?php

namespace App\Filament\Resources\RiderCategoryResource\Pages;

use App\Filament\Resources\RiderCategoryResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateRiderCategory extends CreateRecord
{
    protected static string $resource = RiderCategoryResource::class;
}
