<?php

namespace App\Http\Controllers;

use App\Models\PlayerTeam;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App\Models\Rider;
use App\Services\SettingManager;
use App\Models\Trade;
use Exception;

class PlayerTeamController extends Controller
{
    /**
     * Mostra la pagina per creare una nuova squadra.
     */
    public function create()
    {
        return view('player-team.create');
    }

    /**
     * Salva la nuova squadra nel database.
     */
    public function store(Request $request)
    {
        $request->validate([
            'name' => ['required', 'string', 'max:255', 'unique:player_teams'],
        ]);

        $initialBudget = SettingManager::get('initial_budget');

        PlayerTeam::create([
            'user_id' => Auth::id(),
            'name' => $request->name,
            'balance' => $initialBudget,
        ]);

        return redirect()->route('dashboard');
    }

    /**
     * Mostra la pagina dell'asta con i corridori disponibili.
     */
    public function showAuction()
    {
        $riders = Rider::whereNull('player_team_id')->with('category')->get();
        return view('auction.show', ['riders' => $riders]);
    }

    /**
     * Logica per acquistare un corridore.
     */
    public function buyRider(Rider $rider)
    {
        DB::beginTransaction();
        try {
            $team = Auth::user()->playerTeam;

            if ($rider->player_team_id !== null) {
                return back()->with('error', 'Questo corridore è già stato acquistato!');
            }
            if ($team->balance < $rider->initial_value) {
                return back()->with('error', 'Budget non sufficiente per acquistare questo corridore!');
            }

            $categoryKey = 'max_' . strtolower($rider->category->name);
            $maxForCategory = SettingManager::get($categoryKey);

            if ($maxForCategory !== null) {
                $currentCountForCategory = $team->riders()->where('rider_category_id', $rider->rider_category_id)->count();
                if ($currentCountForCategory >= $maxForCategory) {
                    return back()->with('error', "Hai già raggiunto il numero massimo di corridori per la categoria {$rider->category->name}!");
                }
            }

            $team->balance -= $rider->initial_value;
            $team->save();
            $rider->player_team_id = $team->id;
            $rider->save();

            DB::commit();
            return back()->with('status', "Corridore {$rider->name} acquistato con successo!");
        } catch (Exception $e) {
            DB::rollBack();
            return back()->with('error', "Si è verificato un errore imprevisto durante l'acquisto. Riprova.");
        }
    }

    /**
     * Logica per svincolare un corridore.
     */
    public function releaseRider(Rider $rider)
    {
        DB::beginTransaction();
        try {
            $team = Auth::user()->playerTeam;

            if ($rider->player_team_id !== $team->id) {
                return back()->with('error', 'Non puoi svincolare un corridore che non ti appartiene.');
            }

            $recoveryPercentage = SettingManager::get('release_recovery_percentage_mid_season'); // Assumiamo di essere a metà stagione
            $recoveredValue = floor(($rider->initial_value * $recoveryPercentage) / 100);

            $team->balance += $recoveredValue;
            $team->save();
            $rider->player_team_id = null;
            $rider->save();

            DB::commit();
            return back()->with('status', "Corridore {$rider->name} svincolato! Hai recuperato {$recoveredValue} fantamilioni.");
        } catch (Exception $e) {
            DB::rollBack();
            return back()->with('error', "Si è verificato un errore durante lo svincolo.");
        }
    }

    /**
     * Mostra la pagina del mercato scambi.
     */
    public function showMarket()
    {
        $myTeam = Auth::user()->playerTeam;
        if (!$myTeam) {
            return redirect()->route('player-team.create')->with('error', 'Devi prima creare una squadra per accedere al mercato.');
        }
        
        $myTeamId = $myTeam->id;

        $receivedTrades = Trade::where('receiving_team_id', $myTeamId)
                               ->where('status', 'pending')
                               ->with(['offeringTeam', 'offeredRiders', 'requestedRiders'])
                               ->get();

        $proposedTrades = Trade::where('offering_team_id', $myTeamId)
                               ->where('status', 'pending')
                               ->with(['receivingTeam', 'offeredRiders', 'requestedRiders'])
                               ->get();
        
        $otherTeams = PlayerTeam::where('id', '!=', $myTeamId)->get();

        return view('market.index', [
            'myTeam' => $myTeam,
            'receivedTrades' => $receivedTrades,
            'proposedTrades' => $proposedTrades,
            'otherTeams' => $otherTeams,
        ]);
    }

    /**
     * Accetta una proposta di scambio.
     */
    public function acceptTrade(Trade $trade)
    {
        DB::beginTransaction();
        try {
            $receivingTeam = Auth::user()->playerTeam;

            // 1. Verifica che l'utente sia il destinatario dello scambio
            if ($trade->receiving_team_id !== $receivingTeam->id) {
                return back()->with('error', 'Non puoi accettare uno scambio non indirizzato a te.');
            }

            // 2. Verifica che lo scambio sia ancora pending
            if ($trade->status !== 'pending') {
                return back()->with('error', 'Questo scambio non è più disponibile.');
            }

            // 3. Verifica che tutti i corridori offerti appartengano ancora alla squadra offerente
            $offeredRiders = $trade->riders()->wherePivot('direction', 'offering')->get();
            foreach ($offeredRiders as $rider) {
                if ($rider->player_team_id !== $trade->offering_team_id) {
                    return back()->with('error', "Il corridore {$rider->name} non è più disponibile per lo scambio.");
                }
            }

            // 4. Verifica che tutti i corridori richiesti appartengano ancora alla tua squadra
            $requestedRiders = $trade->riders()->wherePivot('direction', 'receiving')->get();
            foreach ($requestedRiders as $rider) {
                if ($rider->player_team_id !== $trade->receiving_team_id) {
                    return back()->with('error', "Il corridore {$rider->name} non è più nel tuo roster.");
                }
            }

            // 5. Validazione: verifica limiti categoria dopo lo scambio
            $offeringTeam = $trade->offeringTeam;
            
            foreach ($offeredRiders as $rider) {
                $categoryKey = 'max_' . strtolower($rider->category->name);
                $maxForCategory = SettingManager::get($categoryKey);
                
                if ($maxForCategory !== null) {
                    $currentCount = $receivingTeam->riders()
                        ->where('rider_category_id', $rider->rider_category_id)
                        ->count();
                    
                    $givingAwayCount = $requestedRiders->where('rider_category_id', $rider->rider_category_id)->count();
                    
                    if (($currentCount - $givingAwayCount + 1) > $maxForCategory) {
                        return back()->with('error', "Superato il limite massimo per la categoria {$rider->category->name}!");
                    }
                }
            }

            // 6. Esegui lo scambio fisico dei corridori
            foreach ($offeredRiders as $rider) {
                $rider->player_team_id = $trade->receiving_team_id;
                $rider->save();
            }

            foreach ($requestedRiders as $rider) {
                $rider->player_team_id = $trade->offering_team_id;
                $rider->save();
            }

            // 7. Gestisci l'aggiustamento monetario (se presente)
            if ($trade->money_adjustment != 0) {
                $offeringTeam->balance += $trade->money_adjustment;
                $receivingTeam->balance -= $trade->money_adjustment;
                
                if ($receivingTeam->balance < 0) {
                    throw new Exception('Budget insufficiente per completare lo scambio.');
                }
                
                $offeringTeam->save();
                $receivingTeam->save();
            }

            // 8. Aggiorna lo status dello scambio
            $trade->status = 'accepted';
            $trade->save();

            DB::commit();
            return back()->with('status', 'Scambio accettato con successo!');
            
        } catch (Exception $e) {
            DB::rollBack();
            return back()->with('error', 'Errore durante l\'accettazione dello scambio: ' . $e->getMessage());
        }
    }

    /**
     * Rifiuta una proposta di scambio.
     */
    public function rejectTrade(Trade $trade)
    {
        try {
            $receivingTeam = Auth::user()->playerTeam;

            if ($trade->receiving_team_id !== $receivingTeam->id) {
                return back()->with('error', 'Non puoi rifiutare uno scambio non indirizzato a te.');
            }

            if ($trade->status !== 'pending') {
                return back()->with('error', 'Questo scambio è già stato processato.');
            }

            $trade->status = 'rejected';
            $trade->save();

            return back()->with('status', 'Scambio rifiutato.');
            
        } catch (Exception $e) {
            return back()->with('error', 'Errore durante il rifiuto: ' . $e->getMessage());
        }
    }

    /**
     * Cancella una proposta di scambio inviata.
     */
    public function cancelTrade(Trade $trade)
    {
        try {
            $offeringTeam = Auth::user()->playerTeam;

            if ($trade->offering_team_id !== $offeringTeam->id) {
                return back()->with('error', 'Non puoi cancellare uno scambio che non hai proposto.');
            }

            if ($trade->status !== 'pending') {
                return back()->with('error', 'Questo scambio non può più essere cancellato.');
            }

            $trade->status = 'cancelled';
            $trade->save();

            return back()->with('status', 'Proposta di scambio cancellata.');
            
        } catch (Exception $e) {
            return back()->with('error', 'Errore durante la cancellazione: ' . $e->getMessage());
        }
    }
}
